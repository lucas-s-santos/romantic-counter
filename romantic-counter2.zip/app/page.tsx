"use client"

import { useState, useEffect, useRef } from "react"
import { WelcomeScreen } from "@/components/welcome-screen"
import { MainContent } from "@/components/main-content"

export default function Home() {
  const [showMain, setShowMain] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    if (showMain && audioRef.current) {
      audioRef.current.play().catch((error) => {
        console.log("Autoplay prevented:", error)
      })
    }
  }, [showMain])

  return (
    <main className="min-h-screen">
      <audio ref={audioRef} loop>
        <source src="/romantic-music.mp3" type="audio/mpeg" />
      </audio>

      {!showMain ? <WelcomeScreen onEnter={() => setShowMain(true)} /> : <MainContent />}
    </main>
  )
}
