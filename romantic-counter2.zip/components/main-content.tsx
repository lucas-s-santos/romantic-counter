"use client"

import { useEffect, useState } from "react"
import { PhotoCarousel } from "@/components/photo-carousel"
import { Calendar } from "@/components/calendar"
import { Heart } from "lucide-react"

export function MainContent() {
  const [days, setDays] = useState(0)
  const [hours, setHours] = useState(0)
  const [minutes, setMinutes] = useState(0)
  const [seconds, setSeconds] = useState(0)

  useEffect(() => {
    const startDate = new Date("2025-06-12T00:00:00")

    const updateCounter = () => {
      const now = new Date()
      const diff = now.getTime() - startDate.getTime()

      const d = Math.floor(diff / (1000 * 60 * 60 * 24))
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const s = Math.floor((diff % (1000 * 60)) / 1000)

      setDays(d)
      setHours(h)
      setMinutes(m)
      setSeconds(s)
    }

    updateCounter()
    const interval = setInterval(updateCounter, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12 md:py-20 space-y-16 md:space-y-24 max-w-7xl">
        <div className="text-center space-y-4 md:space-y-6 animate-fade-in">
          <div className="flex items-center justify-center gap-3 md:gap-4">
            <Heart className="w-5 h-5 md:w-6 md:h-6 text-foreground fill-foreground animate-pulse" />
            <h1 className="text-4xl md:text-7xl font-serif text-balance text-foreground tracking-tight">
              Lucas e Luisa
            </h1>
            <Heart className="w-5 h-5 md:w-6 md:h-6 text-foreground fill-foreground animate-pulse" />
          </div>
          <p className="text-sm md:text-lg text-muted-foreground font-light tracking-wide">Desde 12 de Junho de 2025</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 max-w-5xl mx-auto animate-fade-in-up">
          <div className="bg-card rounded-lg p-6 md:p-8 shadow-sm border border-border text-center hover:shadow-md transition-shadow">
            <div className="text-4xl md:text-6xl font-serif text-foreground mb-2">{days}</div>
            <div className="text-xs md:text-sm text-muted-foreground uppercase tracking-widest">Dias</div>
          </div>
          <div className="bg-card rounded-lg p-6 md:p-8 shadow-sm border border-border text-center hover:shadow-md transition-shadow">
            <div className="text-4xl md:text-6xl font-serif text-foreground mb-2">{hours}</div>
            <div className="text-xs md:text-sm text-muted-foreground uppercase tracking-widest">Horas</div>
          </div>
          <div className="bg-card rounded-lg p-6 md:p-8 shadow-sm border border-border text-center hover:shadow-md transition-shadow">
            <div className="text-4xl md:text-6xl font-serif text-foreground mb-2">{minutes}</div>
            <div className="text-xs md:text-sm text-muted-foreground uppercase tracking-widest">Minutos</div>
          </div>
          <div className="bg-card rounded-lg p-6 md:p-8 shadow-sm border border-border text-center hover:shadow-md transition-shadow">
            <div className="text-4xl md:text-6xl font-serif text-foreground mb-2">{seconds}</div>
            <div className="text-xs md:text-sm text-muted-foreground uppercase tracking-widest">Segundos</div>
          </div>
        </div>

        <div
          className="flex flex-col lg:flex-row gap-8 lg:gap-16 items-start animate-fade-in-up"
          style={{ animationDelay: "0.2s" }}
        >
          <div className="w-full lg:w-1/2 bg-card rounded-lg p-8 md:p-10 shadow-sm border border-border">
            <h2 className="text-3xl md:text-4xl font-serif text-foreground mb-6 md:mb-8 text-center lg:text-left tracking-tight">
              Nossa História
            </h2>
            <div className="space-y-5 text-sm md:text-base text-foreground/80 leading-relaxed font-light">
              <p>
                Tudo começou no dia 12 de abril, em uma festa chamada Cai de Bico. Foi lá, em meio à música e à energia
                daquela noite, que o destino resolveu cruzar nossos caminhos. Um beijo foi o início de tudo — e logo
                depois dele, eu disse pra ela que iria atrás dela até o fim. E foi exatamente o que fiz.
              </p>
              <p>
                Depois daquela festa, começamos a conversar pelo Instagram, e não demorou muito para marcarmos de nos
                encontrar no Gela Guela. Aquele dia foi especial — foi quando percebi que ela era muito mais do que eu
                imaginava. Conversando, rindo e olhando nos olhos dela, eu descobri que era com ela que eu queria viver
                a minha vida e realizar todos os meus sonhos.
              </p>
              <p>
                Desde então, a gente nunca mais se desgrudou. E no dia 12 de junho, mesmo com pouco tempo pra planejar,
                fiz o pedido de namoro. Queria algo mais elaborado, mas o que realmente importava era o sentimento — e
                aquele momento foi perfeito do nosso jeito.
              </p>
              <p>
                Pouco tempo depois, viajamos pra Campinas, pra casa dos pais dela. E foi lá que eu tive a maior prova do
                amor dela por mim. Ali, percebi o quanto era verdadeiro, o quanto ela me queria por perto, e como fazia
                questão que a família soubesse que estávamos juntos.
              </p>
              <p className="text-foreground font-normal italic">
                Desde aquele dia, tenho certeza de que encontrei o amor da minha vida. E se tudo começou com um beijo em
                uma festa, hoje é uma história que quero continuar escrevendo ao lado dela, todos os dias.
              </p>
            </div>
          </div>

          {/* Photo Carousel */}
          <div className="w-full lg:w-1/2">
            <PhotoCarousel />
          </div>
        </div>

        {/* Calendar */}
        <div className="animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
          <Calendar />
        </div>
      </div>
    </div>
  )
}
