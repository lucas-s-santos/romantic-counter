"use client"

import { Button } from "@/components/ui/button"

interface WelcomeScreenProps {
  onEnter: () => void
}

export function WelcomeScreen({ onEnter }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-muted/20 via-transparent to-muted/20" />

      <div className="max-w-2xl w-full text-center space-y-12 relative z-10">
        <div className="space-y-6 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-serif text-balance text-foreground tracking-tight">
            Um Momento Especial
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground text-pretty font-light">
            Algo foi feito especialmente para você
          </p>
        </div>

        <div className="flex justify-center pt-12 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
          <Button
            onClick={onEnter}
            variant="ghost"
            size="lg"
            className="text-sm tracking-widest uppercase text-muted-foreground hover:text-foreground transition-all duration-500 border border-border hover:border-foreground bg-transparent px-8 py-6"
          >
            CLICK AQUI
          </Button>
        </div>
      </div>
    </div>
  )
}
