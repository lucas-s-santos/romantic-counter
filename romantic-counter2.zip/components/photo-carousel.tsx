"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const photos = [
  {
    url: "/romantic-couple-photo-sunset.jpg",
  },
  {
    url: "/happy-couple-laughing.png",
  },
  {
    url: "/couple-holding-hands-beach.jpg",
  },
  {
    url: "/romantic-dinner-couple.jpg",
  },
  {
    url: "/couple-embracing-nature.jpg",
  },
]

export function PhotoCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      handleNext()
    }, 5000)

    return () => clearInterval(interval)
  }, [currentIndex])

  const handleNext = () => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % photos.length)
      setIsTransitioning(false)
    }, 300)
  }

  const handlePrev = () => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + photos.length) % photos.length)
      setIsTransitioning(false)
    }, 300)
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h2 className="text-3xl md:text-4xl font-serif text-center text-foreground tracking-tight">Nossas Memórias</h2>

      <div className="relative bg-card rounded-lg shadow-sm overflow-hidden border border-border">
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={photos[currentIndex].url || "/placeholder.svg"}
            alt="Nossa foto"
            className={`w-full h-full object-cover transition-all duration-700 ${
              isTransitioning ? "opacity-0 scale-105" : "opacity-100 scale-100"
            }`}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent pointer-events-none" />
        </div>

        <div className="absolute top-1/2 left-4 right-4 -translate-y-1/2 flex justify-between pointer-events-none">
          <Button
            onClick={handlePrev}
            variant="ghost"
            size="icon"
            className="pointer-events-auto rounded-full bg-card/90 hover:bg-card shadow-md border border-border backdrop-blur-sm"
          >
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </Button>
          <Button
            onClick={handleNext}
            variant="ghost"
            size="icon"
            className="pointer-events-auto rounded-full bg-card/90 hover:bg-card shadow-md border border-border backdrop-blur-sm"
          >
            <ChevronRight className="w-5 h-5 text-foreground" />
          </Button>
        </div>

        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
          {photos.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setIsTransitioning(true)
                setTimeout(() => {
                  setCurrentIndex(index)
                  setIsTransitioning(false)
                }, 300)
              }}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                index === currentIndex ? "bg-foreground w-8" : "bg-foreground/30 hover:bg-foreground/50 w-1.5"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
